
import React, { useState } from 'react';
import type { Difficulty } from '../types';
import { BookOpenIcon, BarChartIcon } from './icons';

interface QuizSetupProps {
  onStartQuiz: (topic: string, difficulty: Difficulty) => void;
  initialTopic: string;
  initialDifficulty: Difficulty;
  error: string | null;
}

export const QuizSetup: React.FC<QuizSetupProps> = ({ onStartQuiz, initialTopic, initialDifficulty, error }) => {
  const [topic, setTopic] = useState(initialTopic);
  const [difficulty, setDifficulty] = useState<Difficulty>(initialDifficulty);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (topic.trim()) {
      onStartQuiz(topic, difficulty);
    }
  };

  const difficulties: Difficulty[] = ['Easy', 'Medium', 'Hard'];

  return (
    <div className="bg-slate-800 p-8 rounded-xl shadow-2xl border border-slate-700">
      <h2 className="text-3xl font-bold text-center mb-6 text-cyan-400">Set Up Your Quiz</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="topic" className="block text-sm font-medium text-slate-300 mb-2">Topic</label>
          <div className="relative">
            <BookOpenIcon className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., Python, World History"
              className="w-full pl-10 pr-4 py-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none transition"
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Difficulty</label>
          <div className="relative">
            <BarChartIcon className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as Difficulty)}
              className="w-full appearance-none pl-10 pr-4 py-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none transition"
            >
              {difficulties.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
        </div>
        {error && <p className="text-red-400 text-sm text-center">{error}</p>}
        <button
          type="submit"
          disabled={!topic.trim()}
          className="w-full py-3 px-4 bg-cyan-600 hover:bg-cyan-500 rounded-lg font-semibold text-white transition-all duration-300 disabled:bg-slate-600 disabled:cursor-not-allowed transform hover:scale-105 disabled:transform-none"
        >
          Start Quiz
        </button>
      </form>
    </div>
  );
};
