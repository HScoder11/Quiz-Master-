
import React from 'react';
import type { QuizQuestion } from '../types';
import { CheckIcon, XIcon } from './icons';

interface QuizCardProps {
  question: QuizQuestion;
  questionNumber: number;
  totalQuestions: number;
  onAnswerSelect: (answerKey: string) => void;
  userAnswer: string | null;
  isCorrect: boolean | null;
  onNext: () => void;
  isFeedbackState: boolean;
}

export const QuizCard: React.FC<QuizCardProps> = ({
  question,
  questionNumber,
  totalQuestions,
  onAnswerSelect,
  userAnswer,
  isCorrect,
  onNext,
  isFeedbackState,
}) => {
  const getOptionClasses = (optionKey: string) => {
    let baseClasses = "w-full text-left p-4 my-2 rounded-lg border-2 transition-all duration-300 flex items-center";
    if (!isFeedbackState) {
      return `${baseClasses} bg-slate-700 border-slate-600 hover:bg-slate-600 hover:border-cyan-500 cursor-pointer`;
    }

    const isSelected = userAnswer === optionKey;
    const isCorrectAnswer = question.correctAnswer === optionKey;

    if (isCorrectAnswer) {
      return `${baseClasses} bg-green-900 border-green-500 cursor-default`;
    }
    if (isSelected && !isCorrectAnswer) {
      return `${baseClasses} bg-red-900 border-red-500 cursor-default`;
    }
    return `${baseClasses} bg-slate-800 border-slate-700 cursor-default opacity-60`;
  };

  return (
    <div className="bg-slate-800 p-8 rounded-xl shadow-2xl border border-slate-700 w-full">
      <div className="mb-6">
        <p className="text-sm text-cyan-400 font-semibold">Question {questionNumber} / {totalQuestions}</p>
        <h2 className="text-2xl font-bold mt-2">{question.question}</h2>
      </div>

      <div className="space-y-2">
        {Object.entries(question.options).map(([key, value]) => (
          <button
            key={key}
            onClick={() => onAnswerSelect(key)}
            disabled={isFeedbackState}
            className={getOptionClasses(key)}
          >
            <span className="font-bold mr-4 text-cyan-400">{key}</span>
            <span>{value}</span>
          </button>
        ))}
      </div>

      {isFeedbackState && (
        <div className="mt-6 p-4 rounded-lg bg-slate-900">
          <div className="flex items-center mb-2">
            {isCorrect ? (
              <CheckIcon className="w-6 h-6 text-green-400 mr-2" />
            ) : (
              <XIcon className="w-6 h-6 text-red-400 mr-2" />
            )}
            <h3 className={`text-xl font-bold ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
              {isCorrect ? 'Correct!' : 'Not quite!'}
            </h3>
          </div>
          <p className="text-slate-300">{question.explanation}</p>
          <button
            onClick={onNext}
            className="w-full mt-4 py-3 px-4 bg-cyan-600 hover:bg-cyan-500 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105"
          >
            {questionNumber === totalQuestions ? 'Finish Quiz' : 'Next Question'}
          </button>
        </div>
      )}
    </div>
  );
};
