
import React, { useState, useCallback } from 'react';
import { QuizSetup } from './components/QuizSetup';
import { QuizCard } from './components/QuizCard';
import { LoadingSpinner } from './components/LoadingSpinner';
import { startQuizSession, getNextQuestion } from './services/geminiService';
import type { Difficulty, QuizQuestion } from './types';
import type { Chat } from '@google/genai';
import { TOTAL_QUESTIONS } from './constants';
import { BrainIcon } from './components/icons';

type GameState = 'setup' | 'loading' | 'playing' | 'feedback' | 'finished';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>('setup');
  const [topic, setTopic] = useState<string>('General Knowledge');
  const [difficulty, setDifficulty] = useState<Difficulty>('Easy');
  const [chat, setChat] = useState<Chat | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState<QuizQuestion | null>(null);
  const [questionNumber, setQuestionNumber] = useState(0);
  const [score, setScore] = useState(0);
  const [userAnswer, setUserAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleStartQuiz = useCallback(async (newTopic: string, newDifficulty: Difficulty) => {
    setGameState('loading');
    setError(null);
    setScore(0);
    setQuestionNumber(0);
    setTopic(newTopic);
    setDifficulty(newDifficulty);

    try {
      const newChat = startQuizSession();
      setChat(newChat);
      const firstQuestion = await getNextQuestion(newChat, `Start a new quiz. Topic: ${newTopic}, Difficulty: ${newDifficulty}`);
      setCurrentQuestion(firstQuestion);
      setQuestionNumber(1);
      setGameState('playing');
    } catch (e) {
      setError('Failed to start the quiz. Please check your API key and try again.');
      setGameState('setup');
      console.error(e);
    }
  }, []);

  const handleAnswerSelect = (answerKey: string) => {
    if (!currentQuestion) return;
    setUserAnswer(answerKey);
    const correct = answerKey === currentQuestion.correctAnswer;
    setIsCorrect(correct);
    if (correct) {
      setScore(prev => prev + 1);
    }
    setGameState('feedback');
  };

  const handleNextQuestion = useCallback(async () => {
    if (!chat) return;
    if (questionNumber >= TOTAL_QUESTIONS) {
      setGameState('finished');
      return;
    }

    setGameState('loading');
    setError(null);
    setUserAnswer(null);
    setIsCorrect(null);

    try {
      const nextQuestion = await getNextQuestion(chat, "next");
      setCurrentQuestion(nextQuestion);
      setQuestionNumber(prev => prev + 1);
      setGameState('playing');
    } catch (e) {
      setError('Failed to fetch the next question. Please try again.');
      setGameState('feedback'); // Return to feedback state to allow retry
      console.error(e);
    }
  }, [chat, questionNumber]);

  const handleRestart = () => {
    setGameState('setup');
    setChat(null);
    setCurrentQuestion(null);
    setQuestionNumber(0);
    setScore(0);
    setUserAnswer(null);
    setIsCorrect(null);
    setError(null);
  };

  const renderContent = () => {
    switch (gameState) {
      case 'loading':
        return <LoadingSpinner />;
      case 'playing':
      case 'feedback':
        return currentQuestion && (
          <QuizCard
            question={currentQuestion}
            questionNumber={questionNumber}
            totalQuestions={TOTAL_QUESTIONS}
            onAnswerSelect={handleAnswerSelect}
            userAnswer={userAnswer}
            isCorrect={isCorrect}
            onNext={handleNextQuestion}
            isFeedbackState={gameState === 'feedback'}
          />
        );
      case 'finished':
        return (
          <div className="text-center p-8 bg-slate-800 rounded-lg shadow-2xl">
            <h2 className="text-3xl font-bold text-cyan-400 mb-4">Quiz Complete!</h2>
            <p className="text-xl mb-6">You scored <span className="font-bold text-green-400">{score}</span> out of <span className="font-bold">{TOTAL_QUESTIONS}</span></p>
            <button
              onClick={handleRestart}
              className="px-6 py-3 bg-cyan-600 hover:bg-cyan-500 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105"
            >
              Play Again
            </button>
          </div>
        );
      case 'setup':
      default:
        return (
          <QuizSetup
            onStartQuiz={handleStartQuiz}
            initialTopic={topic}
            initialDifficulty={difficulty}
            error={error}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 font-sans">
      <header className="mb-8 text-center">
        <h1 className="text-5xl font-bold text-white flex items-center justify-center gap-4">
          <BrainIcon className="w-12 h-12 text-cyan-400" />
          AI Quiz Master
        </h1>
        <p className="text-slate-400 mt-2">Test your knowledge with Gemini</p>
      </header>
      <main className="w-full max-w-2xl">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;
