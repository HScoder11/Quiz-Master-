
export const TOTAL_QUESTIONS = 5;
